/* global React, ReactDOM, Icons, ListView, DetailView, useTweaks, TweaksPanel, TweakSection, TweakRadio, TweakSelect, TweakColor, TweakToggle */
const { useState: useStateA, useEffect: useEffectA } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "warm",
  "density": "normal",
  "accentHue": 195,
  "showSpark": true,
  "citation": "chip"
}/*EDITMODE-END*/;

function App() {
  const [view, setView] = useStateA("list"); // "list" | "detail"
  const [activeTab, setActiveTab] = useStateA("tenders");
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);

  useEffectA(() => {
    document.documentElement.setAttribute("data-theme",
      tweaks.theme === "warm" ? "" :
      tweaks.theme === "cool" ? "cool" :
      tweaks.theme === "ink" ? "ink" : "");
    document.documentElement.style.setProperty("--accent", `oklch(0.50 0.05 ${tweaks.accentHue})`);
    document.documentElement.style.setProperty("--accent-2", `oklch(0.42 0.06 ${tweaks.accentHue})`);
    document.documentElement.style.setProperty("--accent-soft", `oklch(0.92 0.03 ${tweaks.accentHue})`);
  }, [tweaks.theme, tweaks.accentHue]);

  const openTender = (id) => {
    setView("detail");
    window.scrollTo(0, 0);
  };

  return (
    <div className="shell">
      <header className="topbar">
        <div className="brand" onClick={() => setView("list")}>
          <div className="brand-mark" />
          <div>
            <div className="brand-text">Carriageway</div>
            <div className="brand-sub">NHAI Tender Intelligence</div>
          </div>
        </div>
        <nav className="topnav">
          <button className={activeTab === "tenders" ? "active" : ""} onClick={() => { setActiveTab("tenders"); setView("list"); }}>
            Tenders <span className="count">12</span>
          </button>
          <button className={activeTab === "memos" ? "active" : ""} onClick={() => setActiveTab("memos")}>
            Memos <span className="count">4</span>
          </button>
          <button className={activeTab === "compare" ? "active" : ""} onClick={() => setActiveTab("compare")}>
            Compare
          </button>
          <button className={activeTab === "alerts" ? "active" : ""} onClick={() => setActiveTab("alerts")}>
            Alerts
          </button>
          <button className={activeTab === "ingest" ? "active" : ""} onClick={() => setActiveTab("ingest")}>
            Ingest
          </button>
        </nav>
        <div className="top-spacer" />
        <div className="searchbar" style={{width:260}}>
          <span style={{display:"flex",color:"var(--ink-4)"}}>{Icons.search}</span>
          <input placeholder="Search analyses, citations, fields…" />
          <span className="kbd">⌘K</span>
        </div>
        <button className="icon-btn" title="Notifications">{Icons.bell}</button>
        <div className="user-pill">
          <div className="av">KC</div>
          <div>
            <div style={{fontWeight:500,color:"var(--ink-2)",lineHeight:1.1}}>K. Choudhary</div>
            <div style={{fontSize:10.5,color:"var(--ink-4)",fontFamily:"var(--mono)",letterSpacing:".04em"}}>EY · AI Incubator</div>
          </div>
        </div>
      </header>

      {view === "list"
        ? <ListView tweaks={tweaks} onOpen={openTender} />
        : <DetailView tweaks={tweaks} onBack={() => setView("list")} />}

      <TweaksPanel title="Tweaks">
        <TweakSection title="Theme">
          <TweakRadio label="Tone" value={tweaks.theme}
                      onChange={(v) => setTweak("theme", v)}
                      options={[{value:"warm",label:"Warm"},{value:"cool",label:"Cool"},{value:"ink",label:"Ink"}]} />
          <TweakSelect label="Citation style" value={tweaks.citation}
                      onChange={(v) => setTweak("citation", v)}
                      options={[{value:"chip",label:"Pill chip · p. N"},{value:"footnote",label:"Footnote ¹²³"},{value:"margin",label:"Margin annotation"}]} />
        </TweakSection>
        <TweakSection title="Layout">
          <TweakRadio label="Density" value={tweaks.density}
                      onChange={(v) => setTweak("density", v)}
                      options={[{value:"compact",label:"Compact"},{value:"normal",label:"Normal"},{value:"roomy",label:"Roomy"}]} />
          <TweakToggle label="Show sparklines" value={tweaks.showSpark} onChange={(v) => setTweak("showSpark", v)} />
        </TweakSection>
        <TweakSection title="Accent">
          <div style={{display:"flex",gap:8,marginTop:6}}>
            {[ {h:195,n:"Teal"}, {h:230,n:"Slate"}, {h:30,n:"Terra"}, {h:90,n:"Olive"}, {h:340,n:"Madder"} ].map(({h,n}) => (
              <button key={h} title={n} onClick={() => setTweak("accentHue", h)}
                style={{
                  width:26,height:26,borderRadius:13,
                  background:`oklch(0.50 0.05 ${h})`,
                  border: tweaks.accentHue === h ? "2px solid var(--ink)" : "1px solid var(--rule)",
                  cursor:"pointer"
                }} />
            ))}
          </div>
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
