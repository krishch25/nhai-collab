/* global React, Icons, Cite, fmtDate, fmtINRPlain, daysUntil, TypeTag, ConfTag */
const { useState: useStateD, useRef: useRefD, useEffect: useEffectD } = React;

// --- PDF Preview Panel ---
function PdfPanel({ page, snippet, total, file, onPage }) {
  const ref = useRefD(null);
  useEffectD(() => {
    if (ref.current) {
      ref.current.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, [page, snippet]);

  // Synthesize page contents based on page number — close to NHAI RFP layouts
  const renderPageContent = (p) => {
    const hl = (text) => {
      if (!snippet) return text;
      const s = snippet.slice(0, 80).toLowerCase();
      const t = text.toLowerCase();
      const i = t.indexOf(s.split(/[.,;]/)[0].slice(0, 30));
      if (i < 0) return text;
      // simpler: highlight a section that starts roughly with snippet
      return text;
    };
    if (p <= 2) {
      return (
        <>
          <p className="center small">REQUEST FOR PROPOSAL</p>
          <p className="center small" style={{marginBottom:18}}>SELECTION OF AUTHORITY ENGINEER</p>
          <h4 style={{textAlign:"center"}}>For Six-Laning of Vadodara–Mumbai Expressway,<br/>Package VIII (NH-748) under Hybrid Annuity Mode</h4>
          <p className="center" style={{margin:"24px 0"}}>NATIONAL HIGHWAYS AUTHORITY OF INDIA<br/><span className="small">G-5 & 6, Sector-10, Dwarka, New Delhi - 110075</span></p>
          <p className="small" style={{marginTop:60,textAlign:"right"}}>RFP No. NHAI/RFP/HAM/2026/0787 · April 2026</p>
        </>
      );
    }
    if (p === 4) {
      return (
        <>
          <h4>SECTION 1 — INVITATION FOR PROPOSAL</h4>
          <h5>1.2 RFP Document Fee</h5>
          <p>{snippet?.includes("11,800")
            ? <mark>RFP Document Fee of ₹11,800/- (Rupees Eleven Thousand Eight Hundred only) inclusive of 18% GST shall be paid through online mode only.</mark>
            : "RFP Document Fee of ₹11,800/- (Rupees Eleven Thousand Eight Hundred only) inclusive of 18% GST shall be paid through online mode only."}
          </p>
          <h5>1.3 Mode of Payment</h5>
          <p>{snippet?.includes("NEFT")
            ? <mark>Payment shall be made online through NEFT/RTGS/Net Banking to the designated NHAI account given below.</mark>
            : "Payment shall be made online through NEFT/RTGS/Net Banking to the designated NHAI account given below."}
          </p>
          <p className="small" style={{marginLeft:14,marginTop:8}}>
            {snippet?.includes("Beneficiary")
              ? <mark>Beneficiary: National Highways Authority of India · A/c No. 10874501239 · IFSC: SBIN0000691 · Bank: SBI, Sector-10 Dwarka Branch.</mark>
              : <>Beneficiary: National Highways Authority of India<br/>A/c No. 10874501239<br/>IFSC: SBIN0000691<br/>Bank: State Bank of India, Sector-10 Dwarka Branch</>}
          </p>
          <h5>1.4 Bid Validity</h5>
          <p>The Proposal shall remain valid for 180 days from the Proposal Due Date. NHAI reserves the right to seek extension of validity should circumstances so require.</p>
        </>
      );
    }
    if (p === 5) {
      return (
        <>
          <h4>SECTION 1 — INVITATION FOR PROPOSAL (contd.)</h4>
          <h5>1.5 Schedule of Bidding Process</h5>
          <p>{snippet?.includes("1100 Hours on 14")
            ? <mark>The Proposal, complete in all respects, must be received not later than 1100 Hours on 14.05.2026 through the e-tendering portal.</mark>
            : "The Proposal, complete in all respects, must be received not later than 1100 Hours on 14.05.2026 through the e-tendering portal."}
          </p>
          <p>{snippet?.includes("Technical Proposals shall be opened")
            ? <mark>Technical Proposals shall be opened on 14.05.2026 at 1500 Hrs in the presence of authorised representatives of the Consultants who choose to attend.</mark>
            : "Technical Proposals shall be opened on 14.05.2026 at 1500 Hrs in the presence of authorised representatives of the Consultants who choose to attend."}
          </p>
          <h5>1.6 Financial Eligibility</h5>
          <p>{snippet?.includes("turnover of not less")
            ? <mark>The Consultant shall have an average annual turnover of not less than ₹15 Crore from consulting services in the immediately preceding three financial years.</mark>
            : "The Consultant shall have an average annual turnover of not less than ₹15 Crore from consulting services in the immediately preceding three financial years."}
          </p>
        </>
      );
    }
    if (p === 6) {
      return (
        <>
          <h4>SECTION 2 — INSTRUCTIONS TO BIDDERS</h4>
          <h5>2.1 Earnest Money Deposit</h5>
          <p>{snippet?.includes("42,00,000")
            ? <mark>Earnest Money Deposit of ₹42,00,000/- shall be furnished as Bank Guarantee from a Scheduled Commercial Bank, valid for 225 days from PDD.</mark>
            : "Earnest Money Deposit of ₹42,00,000/- shall be furnished as Bank Guarantee from a Scheduled Commercial Bank, valid for 225 days from PDD."}
          </p>
          <p className="small">Format of EMD Bank Guarantee is provided at Form-XII to this RFP.</p>
        </>
      );
    }
    if (p === 7) {
      return (
        <>
          <h4>SECTION 3 — SELECTION CRITERIA</h4>
          <h5>3.1 Selection Methodology</h5>
          <p>{snippet?.includes("Quality and Cost")
            ? <mark>Selection shall be made through Quality and Cost Based Selection (QCBS) method as detailed in this Section.</mark>
            : "Selection shall be made through Quality and Cost Based Selection (QCBS) method as detailed in this Section."}
          </p>
          <p>The Composite Score shall be calculated as: Composite Score = 0.80 × Technical Score + 0.20 × Financial Score. The Consultant securing the highest Composite Score shall be considered for award of the assignment.</p>
          <h5>3.2 Minimum Technical Qualifying</h5>
          <p>{snippet?.includes("75 or more")
            ? <mark>Only those Consultants whose Technical Proposal scores 75 or more marks shall be considered qualified for opening of Financial Proposal.</mark>
            : "Only those Consultants whose Technical Proposal scores 75 or more marks shall be considered qualified for opening of Financial Proposal."}
          </p>
        </>
      );
    }
    if (p === 12) {
      return (
        <>
          <h4>SECTION 1.5 — KEY DATES (contd.)</h4>
          <p>{snippet?.includes("Pre-Bid Meeting")
            ? <mark>A Pre-Bid Meeting shall be held on 22.04.2026 at 1100 Hrs at NHAI HQ, Sector-10, Dwarka, New Delhi-110075. Consultants are encouraged to attend.</mark>
            : "A Pre-Bid Meeting shall be held on 22.04.2026 at 1100 Hrs at NHAI HQ, Sector-10, Dwarka, New Delhi-110075. Consultants are encouraged to attend."}
          </p>
          <p>{snippet?.includes("clarifications in writing")
            ? <mark>Consultants may seek clarifications in writing up to 29.04.2026 (1700 Hrs). Subsequent queries shall not be entertained.</mark>
            : "Consultants may seek clarifications in writing up to 29.04.2026 (1700 Hrs). Subsequent queries shall not be entertained."}
          </p>
          <p className="small">All clarifications shall be addressed to the SPOC named at Section 1.7 with subject line "Clarification — RFP/HAM/2026/0787".</p>
        </>
      );
    }
    if (p === 22) {
      return (
        <>
          <h4>SECTION 1.7 — CONTACT FOR CORRESPONDENCE</h4>
          <p>All correspondence in respect of this RFP shall be addressed to:</p>
          <p style={{marginLeft:20}}>
            <b>Sandeep R. Kulkarni</b><br/>
            General Manager (Technical)<br/>
            Project Implementation Unit — Vadodara<br/>
            National Highways Authority of India<br/>
            4th Floor, Sayaji Chambers, Sayajigunj,<br/>
            Vadodara — 390005, Gujarat<br/>
            Phone: +91 265 234 5670<br/>
            Email: piu.vadodara@nhai.gov.in
          </p>
        </>
      );
    }
    if (p === 73) {
      return (
        <>
          <h4>FORM-I — LETTER OF PROPOSAL</h4>
          <p className="small">(On Letterhead of the Lead Member of Consortium / Sole Firm)</p>
          <p style={{marginTop:20}}>To,<br/>The General Manager (Technical),<br/>National Highways Authority of India</p>
          <p style={{marginTop:14}}>Sir,</p>
          <p>With reference to your RFP Document dated 8th April 2026, we, having examined all relevant documents and understood their contents, hereby submit our Proposal for Selection as Authority Engineer for the captioned Assignment.</p>
          <p>The Proposal is unconditional and unqualified.</p>
          <p style={{marginTop:30}}>____________________________<br/>(Signature of Authorised Signatory)</p>
        </>
      );
    }
    return (
      <>
        <h4 className="small">SECTION CONTENT — Page {p}</h4>
        <p className="small" style={{color:"var(--ink-5)",fontStyle:"italic"}}>
          [Synthesized preview. In production this is the actual rendered PDF page from Supabase Storage. Click any citation chip in the analysis pane to jump here and highlight the exact source quote.]
        </p>
      </>
    );
  };

  return (
    <aside className="pdf-panel">
      <div className="pdf-head">
        <button className="step" onClick={() => onPage(Math.max(1, page - 1))} disabled={page <= 1}>{Icons.back}</button>
        <button className="step" onClick={() => onPage(Math.min(total, page + 1))} disabled={page >= total}>{Icons.fwd}</button>
        <select value={file}>
          <option value="RFP_787.pdf">RFP_787.pdf · 251 pp</option>
          <option value="NIT_787.pdf">NIT_787.pdf · 18 pp</option>
          <option value="BOQ_787.xlsx">BOQ_787.xlsx · 4 sheets</option>
          <option value="Annex_A.pdf">Annex_A.pdf · 64 pp</option>
        </select>
        <span className="pageinfo">{page} / {total}</span>
        <button className="step" title="Zoom">{Icons.zoom_in}</button>
        <button className="step" title="Open external">{Icons.external}</button>
      </div>
      <div className="pdf-body" ref={ref}>
        <div className="pdf-page" key={page}>
          <div className="pn">{file} · p. {page}</div>
          {renderPageContent(page)}
        </div>
      </div>
    </aside>
  );
}

// --- Section components ---
function FieldRow({ label, value, page, snippet, onJump, na, source = "RFP_787.pdf" }) {
  return (
    <>
      <div className="flabel">{label}</div>
      <div className="fvalue">
        {na || !value ? <span className="na">N/A — not found in document</span> : <span>{value}</span>}
        {page && <Cite page={page} snippet={snippet} source={source} onJump={onJump} />}
      </div>
    </>
  );
}

function Section({ id, num, title, conf = "high", children, side }) {
  const inner = side ? (
    <div className="annot">
      <div className="body">{children}</div>
      <div className="aside">{side}</div>
    </div>
  ) : children;
  return (
    <section className="section" id={id}>
      <div className="section-head">
        <span className="num">§ {num}</span>
        <h2>{title}</h2>
        <span className={"conf " + conf}><span className="dot" /> {conf} confidence</span>
      </div>
      {inner}
    </section>
  );
}

// --- Detail view ---
function DetailView({ tweaks, onBack }) {
  const t = window.TENDER_DETAIL;
  const [page, setPage] = useStateD(t.pdfMap.overview);
  const [snippet, setSnippet] = useStateD(null);
  const [activeSection, setActiveSection] = useStateD("dates");
  const mainRef = useRefD(null);

  const jump = (p, s) => {
    setPage(p);
    setSnippet(s || null);
  };

  // Section nav scrollspy
  useEffectD(() => {
    const sections = ["dates","fees","elig","eval","scope","sub","contact","pay","risk","forms"];
    const onScroll = () => {
      if (!mainRef.current) return;
      let cur = sections[0];
      for (const s of sections) {
        const el = document.getElementById(s);
        if (el && el.getBoundingClientRect().top < 120) cur = s;
      }
      setActiveSection(cur);
    };
    const el = mainRef.current;
    el && el.addEventListener("scroll", onScroll);
    return () => el && el.removeEventListener("scroll", onScroll);
  }, []);

  const navTo = (id) => {
    const el = document.getElementById(id);
    if (el && mainRef.current) {
      const top = el.offsetTop - 16;
      mainRef.current.scrollTo({ top, behavior: "smooth" });
    }
  };

  const sections = [
    { id: "dates", num: "01", label: "Key Dates", count: 7 },
    { id: "fees", num: "02", label: "RFP Fees & Securities", count: 4 },
    { id: "elig", num: "03", label: "Eligibility", count: 11 },
    { id: "eval", num: "04", label: "Evaluation Criteria", count: 6 },
    { id: "scope", num: "05", label: "Scope of RFP", count: 18 },
    { id: "sub", num: "06", label: "Submission Mechanisms", count: 12 },
    { id: "contact", num: "07", label: "Contact / SPOC", count: 1 },
    { id: "pay", num: "08", label: "Payment Terms", count: 5 },
    { id: "risk", num: "09", label: "Risk & Regulatory", count: 7 },
    { id: "forms", num: "10", label: "Documents & Forms", count: 14 },
  ];

  const dCount = daysUntil(t.deadline);

  return (
    <div className="detail-wrap">
      {/* Section nav */}
      <nav className="section-nav">
        <div className="nav-label">Analysis Sections</div>
        {sections.map(s => (
          <a key={s.id}
             className={activeSection === s.id ? "active" : ""}
             onClick={() => navTo(s.id)}>
            <span className="num">{s.num}</span>
            <span style={{flex:1}}>{s.label}</span>
            <span className="badge">{s.count}</span>
          </a>
        ))}
        <div className="group">
          <div className="nav-label">Tools</div>
          <a><span className="num">▸</span><span>Compare to similar</span></a>
          <a><span className="num">▸</span><span>Bid/no-bid memo</span></a>
          <a><span className="num">▸</span><span>Re-run analysis</span></a>
        </div>
      </nav>

      {/* Main */}
      <main className="detail-main" ref={mainRef}>
        {/* Header */}
        <div className="detail-head">
          <div className="crumb">
            <a onClick={onBack} style={{cursor:"pointer", textDecoration:"underline", textUnderlineOffset:3}}>Tenders</a>
            <span className="sep">/</span>
            <span>{t.no}</span>
            <span className="sep">/</span>
            <span>#{t.id}</span>
          </div>
          <h1>{t.title}</h1>
          <div className="meta-line">
            <span><b>{t.nh}</b> · {t.chainage}</span>
            <span><b>{t.length} km</b> · {t.state}</span>
            <span><b>{fmtINRPlain(t.contractValue * 10000000)}</b> est. project cost</span>
            <span><b>Construction:</b> {t.duration}</span>
            <TypeTag t={t.type} />
            <ConfTag c={t.confidence} />
          </div>

          <div style={{
            marginTop: 22,
            padding: "14px 16px",
            borderLeft: "2px solid var(--accent)",
            background: "var(--paper-2)",
            display: "flex",
            gap: 24,
            alignItems: "center"
          }}>
            <div>
              <div style={{fontFamily:"var(--mono)",fontSize:9.5,letterSpacing:".1em",textTransform:"uppercase",color:"var(--ink-4)"}}>Bid due in</div>
              <div style={{fontFamily:"var(--serif)",fontSize:32,fontWeight:500,letterSpacing:"-.012em",lineHeight:1,marginTop:2}}>
                {dCount}<span style={{fontFamily:"var(--mono)",fontSize:13,color:"var(--ink-4)",marginLeft:6}}>days</span>
              </div>
            </div>
            <div style={{width:1,height:36,background:"var(--rule)"}} />
            <div style={{flex:1, fontSize:13, lineHeight:1.5, color:"var(--ink-2)"}}>
              {t.summary}
            </div>
            <div style={{display:"flex",gap:6}}>
              <button className="btn"><span style={{display:"flex"}}>{Icons.flag}</span> Track</button>
              <button className="btn primary">Generate memo</button>
            </div>
          </div>
        </div>

        {/* Section 1 — Key Dates */}
        <Section id="dates" num="01" title="Key Dates" conf="high"
          side={
            <>
              <div className="ttl">Source pages</div>
              <p style={{margin:"4px 0 12px"}}>Pages 5, 12, 13, 14 of <span className="mono">RFP_787.pdf</span> — Section 1.5 (Schedule of Bidding) and Section 1.4 (Validity).</p>
              <div className="ttl">Validation</div>
              <p>All 7 fields populated. Deadline cross-checks against NHAI tenderlist API metadata.</p>
            </>
          }
        >
          <div className="deadlines" style={{marginBottom:24}}>
            <div className="dline"><div className="lbl">Pre-bid meeting</div><div className="day">22</div><div className="mon">Apr 2026 · 11:00</div><div className="tx">NHAI HQ, Dwarka</div></div>
            <div className="dline"><div className="lbl">Clarification</div><div className="day">29</div><div className="mon">Apr 2026 · 17:00</div><div className="tx">In writing only</div></div>
            <div className="dline" style={{borderColor:"var(--accent)",background:"var(--accent-soft)"}}><div className="lbl" style={{color:"var(--accent-2)"}}>Submission deadline</div><div className="day">14</div><div className="mon">May 2026 · 11:00</div><div className="tx" style={{color:"var(--accent-2)"}}><b>9 days remaining</b></div></div>
            <div className="dline"><div className="lbl">Technical opening</div><div className="day">14</div><div className="mon">May 2026 · 15:00</div><div className="tx">Same day</div></div>
            <div className="dline"><div className="lbl">Financial opening</div><div className="day">—</div><div className="mon">Intimated later</div><div className="tx">After tech eval</div></div>
          </div>

          <div className="fgrid">
            <FieldRow label="Pre-bid meeting" value={t.key_dates.pre_bid_meeting.value} page={t.key_dates.pre_bid_meeting.page} snippet={t.key_dates.pre_bid_meeting.snippet} onJump={jump} />
            <FieldRow label="Last date for clarification" value={t.key_dates.last_date_clarification.value} page={t.key_dates.last_date_clarification.page} snippet={t.key_dates.last_date_clarification.snippet} onJump={jump} />
            <FieldRow label="Proposal submission deadline" value={t.key_dates.proposal_submission_deadline.value} page={t.key_dates.proposal_submission_deadline.page} snippet={t.key_dates.proposal_submission_deadline.snippet} onJump={jump} />
            <FieldRow label="Technical bid opening" value={t.key_dates.technical_bid_opening.value} page={t.key_dates.technical_bid_opening.page} snippet={t.key_dates.technical_bid_opening.snippet} onJump={jump} />
            <FieldRow label="Financial bid opening" value={t.key_dates.financial_bid_opening.value} page={t.key_dates.financial_bid_opening.page} snippet={t.key_dates.financial_bid_opening.snippet} onJump={jump} />
            <FieldRow label="Bid validity period" value={t.key_dates.bid_validity.value} page={t.key_dates.bid_validity.page} snippet={t.key_dates.bid_validity.snippet} onJump={jump} />
            <FieldRow label="Document download period" value={t.key_dates.document_download.value} page={t.key_dates.document_download.page} snippet={t.key_dates.document_download.snippet} onJump={jump} />
          </div>
        </Section>

        {/* Section 2 — RFP Fees */}
        <Section id="fees" num="02" title="RFP Fees & Securities" conf="high">
          <div className="fgrid">
            <FieldRow label="RFP document fee" value={t.rfp_fees.rfp_fee_amount.value} page={t.rfp_fees.rfp_fee_amount.page} snippet={t.rfp_fees.rfp_fee_amount.snippet} onJump={jump} />
            <FieldRow label="Payment mode" value={t.rfp_fees.payment_mode.value} page={t.rfp_fees.payment_mode.page} snippet={t.rfp_fees.payment_mode.snippet} onJump={jump} />
            <div className="flabel">Bank account details</div>
            <div className="fvalue" style={{flexDirection:"column",alignItems:"flex-start",gap:6}}>
              <div style={{display:"grid",gridTemplateColumns:"110px 1fr",rowGap:4,fontSize:13.5}}>
                <span style={{color:"var(--ink-4)"}}>Beneficiary</span><span>{t.rfp_fees.bank.beneficiary}</span>
                <span style={{color:"var(--ink-4)"}}>A/c No.</span><span className="mono">{t.rfp_fees.bank.account}</span>
                <span style={{color:"var(--ink-4)"}}>IFSC</span><span className="mono">{t.rfp_fees.bank.ifsc}</span>
                <span style={{color:"var(--ink-4)"}}>Bank</span><span>{t.rfp_fees.bank.bank}</span>
              </div>
              <Cite page={t.rfp_fees.bank.page} snippet={t.rfp_fees.bank.snippet} onJump={jump} />
            </div>
            <FieldRow label="Earnest money deposit" value={t.rfp_fees.emd_amount.value} page={t.rfp_fees.emd_amount.page} snippet={t.rfp_fees.emd_amount.snippet} onJump={jump} />
            <FieldRow label="Performance security" value={t.rfp_fees.performance_security.value} page={t.rfp_fees.performance_security.page} snippet={t.rfp_fees.performance_security.snippet} onJump={jump} />
          </div>
        </Section>

        {/* Section 3 — Eligibility */}
        <Section id="elig" num="03" title="Eligibility Criteria" conf="high">
          <h3 style={{fontFamily:"var(--serif)",fontSize:15,fontWeight:500,margin:"4px 0 6px",letterSpacing:"-.005em"}}>Technical Eligibility</h3>
          <div className="fgrid" style={{marginBottom:28}}>
            <FieldRow label="Min. annual turnover" value={t.eligibility.technical.min_annual_turnover.value} page={t.eligibility.technical.min_annual_turnover.page} snippet={t.eligibility.technical.min_annual_turnover.snippet} onJump={jump} />
            <FieldRow label="Similar project experience" value={t.eligibility.technical.similar_project_experience.value} page={t.eligibility.technical.similar_project_experience.page} snippet={t.eligibility.technical.similar_project_experience.snippet} onJump={jump} />
            <FieldRow label="JV conditions" value={t.eligibility.technical.jv.value} page={t.eligibility.technical.jv.page} snippet={t.eligibility.technical.jv.snippet} onJump={jump} />
            <FieldRow label="Ongoing assignment cap" value={t.eligibility.technical.ongoing_cap.value} page={t.eligibility.technical.ongoing_cap.page} snippet={t.eligibility.technical.ongoing_cap.snippet} onJump={jump} />
            <div className="flabel">Key personnel required</div>
            <div className="fvalue" style={{flexDirection:"column",alignItems:"flex-start",padding:"10px 0"}}>
              <table className="dtable" style={{marginTop:4}}>
                <thead><tr><th>Role</th><th style={{width:80}}>Min. exp.</th><th style={{width:60}}></th></tr></thead>
                <tbody>
                  {t.eligibility.technical.key_personnel.map((kp, i) => (
                    <tr key={i}>
                      <td>{kp.role}</td>
                      <td className="num">{kp.years} yrs</td>
                      <td><Cite page={kp.page} onJump={jump} snippet={`Position requires ${kp.years} years experience as per Form-IX requirements.`} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <h3 style={{fontFamily:"var(--serif)",fontSize:15,fontWeight:500,margin:"4px 0 6px",letterSpacing:"-.005em"}}>Financial Eligibility</h3>
          <div className="fgrid">
            <FieldRow label="Min. annual turnover" value={t.eligibility.financial.min_annual_turnover.value} page={t.eligibility.financial.min_annual_turnover.page} snippet={t.eligibility.financial.min_annual_turnover.snippet} onJump={jump} />
            <FieldRow label="Net worth requirement" value={t.eligibility.financial.net_worth.value} page={t.eligibility.financial.net_worth.page} snippet={t.eligibility.financial.net_worth.snippet} onJump={jump} />
            <FieldRow label="Financial years considered" value={t.eligibility.financial.financial_years.value} page={t.eligibility.financial.financial_years.page} snippet={t.eligibility.financial.financial_years.snippet} onJump={jump} />
          </div>
        </Section>

        {/* Section 4 — Evaluation */}
        <Section id="eval" num="04" title="Evaluation Criteria" conf="high">
          <div className="annot">
            <div className="body">
              <div className="fgrid">
                <FieldRow label="Selection method" value={t.evaluation.method.value} page={t.evaluation.method.page} snippet={t.evaluation.method.snippet} onJump={jump} />
                <div className="flabel">Weightage</div>
                <div className="fvalue">
                  <span className="num">Technical {t.evaluation.technical_weight.value}</span>
                  <span style={{color:"var(--ink-5)"}}>+</span>
                  <span className="num">Financial {t.evaluation.financial_weight.value}</span>
                  <Cite page={t.evaluation.technical_weight.page} snippet={t.evaluation.method.snippet} onJump={jump} />
                </div>
                <FieldRow label="Min. technical qualifying" value={t.evaluation.technical_min_qualifying.value} page={t.evaluation.technical_min_qualifying.page} snippet={t.evaluation.technical_min_qualifying.snippet} onJump={jump} />
              </div>

              <h3 style={{fontFamily:"var(--serif)",fontSize:15,fontWeight:500,margin:"22px 0 6px",letterSpacing:"-.005em"}}>Per-criterion marks (out of 100)</h3>
              <table className="dtable">
                <thead><tr><th>Criterion</th><th style={{width:90,textAlign:"right"}}>Max marks</th><th style={{width:120}}>Weightage bar</th><th style={{width:60}}></th></tr></thead>
                <tbody>
                  {t.evaluation.criteria.map((c,i) => (
                    <tr key={i}>
                      <td>{c.criterion}</td>
                      <td className="num" style={{textAlign:"right"}}>{c.marks}</td>
                      <td><div className="match-bar" style={{maxWidth:100}}><span style={{width:`${c.marks}%`}} /></div></td>
                      <td><Cite page={c.page} snippet={`${c.criterion} — ${c.marks} marks max`} onJump={jump} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p style={{marginTop:14,fontSize:13,color:"var(--ink-3)",fontStyle:"italic"}}>Formula: {t.evaluation.formula}</p>
            </div>
            <div className="aside">
              <div className="ttl">EY position</div>
              <p>EY exceeds turnover (₹85 Cr avg.) and personnel requirements. Personnel marks are heaviest (50/100) — emphasize Senior Highway Engineer + Bridge Engineer CVs.</p>
              <div className="ttl" style={{marginTop:14}}>Risk</div>
              <p>QCBS with 80/20 — quality dominates. Tightening financial bid below 95% of estimate yields negligible composite gain.</p>
            </div>
          </div>
        </Section>

        {/* Section 5 — Scope */}
        <Section id="scope" num="05" title="Scope of RFP" conf="high">
          <div className="fgrid" style={{marginBottom:24}}>
            <FieldRow label="Project location" value={t.scope.location.value} page={t.scope.location.page} snippet={t.scope.location.snippet} onJump={jump} />
            <FieldRow label="Contract duration" value={t.scope.contract_duration.value} page={t.scope.contract_duration.page} snippet={t.scope.contract_duration.snippet} onJump={jump} />
          </div>
          <h3 style={{fontFamily:"var(--serif)",fontSize:15,fontWeight:500,margin:"4px 0 10px"}}>In-scope tasks</h3>
          <ul className="bulletlist" style={{marginBottom:24}}>
            {t.scope.in_scope.map((s,i) => (
              <li key={i}>
                <span className="marker">{String(i+1).padStart(2,"0")}</span>
                <div className="body">
                  {s.d}
                  <Cite page={s.page} onJump={jump} snippet={s.d} />
                </div>
              </li>
            ))}
          </ul>
          <h3 style={{fontFamily:"var(--serif)",fontSize:15,fontWeight:500,margin:"4px 0 10px"}}>Deliverables & milestones</h3>
          <table className="dtable">
            <thead><tr><th>Deliverable</th><th style={{width:200}}>Timeline</th><th style={{width:60}}></th></tr></thead>
            <tbody>
              {t.scope.deliverables.map((d,i) => (
                <tr key={i}>
                  <td>{d.name}</td>
                  <td className="num">{d.timeline}</td>
                  <td><Cite page={d.page} onJump={jump} snippet={`${d.name} — ${d.timeline}`} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Section>

        {/* Section 6 — Submission */}
        <Section id="sub" num="06" title="Submission Mechanisms" conf="high">
          <div className="fgrid" style={{marginBottom:24}}>
            <FieldRow label="Submission mode" value={t.submission.mode.value} page={t.submission.mode.page} snippet={t.submission.mode.snippet} onJump={jump} />
            <FieldRow label="Portal" value={t.submission.portal.value} page={t.submission.portal.page} snippet={`Submission via ${t.submission.portal.value}`} onJump={jump} />
            <FieldRow label="Number of copies" value={t.submission.copies.value} page={t.submission.copies.page} snippet={t.submission.copies.value} onJump={jump} />
            <FieldRow label="Language" value={t.submission.language.value} page={16} snippet={`All submissions shall be in ${t.submission.language.value}.`} onJump={jump} />
          </div>
          <h3 style={{fontFamily:"var(--serif)",fontSize:15,fontWeight:500,margin:"4px 0 10px"}}>Required forms (12)</h3>
          <table className="dtable">
            <thead><tr><th style={{width:80}}>Form</th><th>Description</th><th style={{width:240}}>Signing authority</th><th style={{width:60}}>Mand.</th><th style={{width:60}}></th></tr></thead>
            <tbody>
              {t.submission.forms.map((f,i) => (
                <tr key={i}>
                  <td className="mono">{f.id}</td>
                  <td>{f.name}</td>
                  <td style={{color:"var(--ink-3)"}}>{f.auth}</td>
                  <td>{f.mandatory ? <span className="tag high" style={{padding:"0 5px"}}>Yes</span> : <span className="tag" style={{padding:"0 5px"}}>Opt.</span>}</td>
                  <td><Cite page={f.page} onJump={jump} snippet={`${f.id} — ${f.name} — Signed by: ${f.auth}`} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Section>

        {/* Section 7 — Contact */}
        <Section id="contact" num="07" title="Contact / SPOC" conf="high">
          <div className="annot">
            <div className="body">
              <div style={{
                fontFamily:"var(--serif)",
                fontSize: 18,
                fontWeight: 500,
                lineHeight: 1.55,
              }}>
                {t.contact.name}<br/>
                <span style={{fontSize:13.5,color:"var(--ink-3)",fontFamily:"var(--sans)",fontWeight:400}}>{t.contact.designation}<br/>{t.contact.department}</span>
              </div>
              <div style={{borderTop:"1px solid var(--rule)",marginTop:18,paddingTop:14, fontSize:13.5, color:"var(--ink-2)", lineHeight:1.6}}>
                {t.contact.address}<br/>
                <span className="mono">{t.contact.phone}</span> · <span className="mono">{t.contact.email}</span>
              </div>
              <div style={{marginTop:14}}>
                <Cite page={t.contact.page} onJump={jump} snippet={`${t.contact.name}, ${t.contact.designation}, ${t.contact.address}`} />
              </div>
            </div>
            <div className="aside">
              <div className="ttl">Channel rules</div>
              <p>All clarifications in writing. No email after 29 Apr 17:00. Subject line: "Clarification — RFP/HAM/2026/0787".</p>
            </div>
          </div>
        </Section>

        {/* Section 8 — Payment */}
        <Section id="pay" num="08" title="Payment Terms" conf="medium">
          <table className="dtable">
            <thead><tr><th>Milestone</th><th style={{width:80,textAlign:"right"}}>%</th><th>Condition</th><th style={{width:60}}></th></tr></thead>
            <tbody>
              {t.payment.map((p,i) => (
                <tr key={i}>
                  <td><b>{p.milestone}</b></td>
                  <td className="num" style={{textAlign:"right"}}>{p.pct}</td>
                  <td style={{color:"var(--ink-3)"}}>{p.cond}</td>
                  <td><Cite page={p.page} snippet={`${p.milestone} — ${p.pct}: ${p.cond}`} onJump={jump} /></td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="footnote">Confidence: medium — milestone 5 (O&M) condition language is non-standard; recommend verification at pre-bid.</div>
        </Section>

        {/* Section 9 — Risk */}
        <Section id="risk" num="09" title="Risk & Regulatory" conf="medium">
          <div className="fgrid">
            <FieldRow label="Liquidated damages" value={t.risk.liquidated_damages.value} page={t.risk.liquidated_damages.page} snippet={`Liquidated damages of ${t.risk.liquidated_damages.value}`} onJump={jump} />
            <FieldRow label="Force majeure" value={t.risk.force_majeure.value} page={t.risk.force_majeure.page} snippet={t.risk.force_majeure.value} onJump={jump} />
            <FieldRow label="Dispute resolution" value={t.risk.dispute.value} page={t.risk.dispute.page} snippet={t.risk.dispute.value} onJump={jump} />
            <FieldRow label="Integrity pact" value={t.risk.integrity_pact.value} page={t.risk.integrity_pact.page} snippet={t.risk.integrity_pact.value} onJump={jump} />
            <div className="flabel">Termination conditions</div>
            <div className="fvalue" style={{flexDirection:"column",alignItems:"flex-start"}}>
              <ul className="bulletlist" style={{width:"100%"}}>
                {t.risk.termination.map((c,i) => (
                  <li key={i}><span className="marker">{String(i+1).padStart(2,"0")}</span><div className="body">{c}</div></li>
                ))}
              </ul>
              <Cite page={92} onJump={jump} snippet="Termination conditions per Section 7.4" />
            </div>
            <div className="flabel">Insurance requirements</div>
            <div className="fvalue" style={{flexDirection:"column",alignItems:"flex-start"}}>
              {t.risk.insurance.map((c,i) => <div key={i} style={{padding:"4px 0"}}>· {c}</div>)}
              <Cite page={94} onJump={jump} snippet="Insurance per Section 7.6" />
            </div>
          </div>
        </Section>

        {/* Section 10 — Forms */}
        <Section id="forms" num="10" title="Documents & Forms" conf="high">
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
            gap: 1,
            background: "var(--rule)",
            border: "1px solid var(--rule)"
          }}>
            {[
              { name: "RFP_787.pdf", desc: "Request for Proposal", size: "8.4 MB", pages: 251, primary: true },
              { name: "NIT_787.pdf", desc: "Notice Inviting Tender", size: "412 KB", pages: 18 },
              { name: "BOQ_787.xlsx", desc: "Bill of Quantities", size: "284 KB", sheets: 4 },
              { name: "Annex_A.pdf", desc: "Concession Agreement", size: "3.1 MB", pages: 64 },
              { name: "Annex_B.pdf", desc: "Technical Specifications", size: "12.8 MB", pages: 184 },
              { name: "Annex_C.pdf", desc: "Drawings & Layouts", size: "22.4 MB", pages: 36 },
              { name: "Annex_D.pdf", desc: "Environmental Clearances", size: "1.2 MB", pages: 28 },
              { name: "Form_IX.pdf", desc: "Personnel CV Format", size: "146 KB", pages: 8, isForm: true },
              { name: "Form_XII.pdf", desc: "Integrity Pact", size: "98 KB", pages: 6, isForm: true },
              { name: "Corrigendum_01.pdf", desc: "Amendment dated 18 Apr", size: "224 KB", pages: 4 },
              { name: "Reply_Queries.pdf", desc: "Pre-bid queries reply", size: "412 KB", pages: 12 },
              { name: "Schedule_K.pdf", desc: "O&M obligations", size: "486 KB", pages: 22 },
              { name: "Drawings_Plan.pdf", desc: "Plan & Profile", size: "9.1 MB", pages: 18 },
              { name: "Drawings_X.pdf", desc: "Cross-section details", size: "6.4 MB", pages: 14 },
            ].map((f, i) => (
              <div key={i} style={{
                background: "var(--paper)",
                padding: "12px 14px",
                display: "flex",
                flexDirection: "column",
                gap: 4,
                cursor: "pointer"
              }}>
                <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:8}}>
                  <div className="mono" style={{fontSize:11.5, color: f.primary ? "var(--accent-2)" : "var(--ink-2)", fontWeight: f.primary ? 600 : 500, wordBreak:"break-all"}}>{f.name}</div>
                  {f.isForm && <span className="tag" style={{height:14,padding:"0 4px",fontSize:8.5}}>FORM</span>}
                  {f.primary && <span className="tag" style={{height:14,padding:"0 4px",fontSize:8.5,borderColor:"var(--accent)",color:"var(--accent-2)"}}>PRIMARY</span>}
                </div>
                <div style={{fontSize:12,color:"var(--ink-3)"}}>{f.desc}</div>
                <div style={{fontFamily:"var(--mono)",fontSize:10,color:"var(--ink-4)",marginTop:4}}>
                  {f.size}{f.pages ? ` · ${f.pages} pp` : ""}{f.sheets ? ` · ${f.sheets} sheets` : ""}
                </div>
              </div>
            ))}
          </div>
        </Section>

        <div style={{marginTop:80, paddingTop:24, borderTop:"1px solid var(--rule)", fontFamily:"var(--mono)", fontSize:11, color:"var(--ink-4)", display:"flex",justifyContent:"space-between"}}>
          <span>Analysis v1.0 · model gpt-4o · t = 0.0 · {t.pdfTotalPages} pages indexed</span>
          <span>Analyzed 04 May 2026 03:42 IST · {Math.round(t.pages * 0.92)} sec runtime</span>
        </div>
      </main>

      {/* PDF panel */}
      <PdfPanel page={page} snippet={snippet} total={t.pdfTotalPages} file={t.sourcePdf} onPage={setPage} />
    </div>
  );
}
window.DetailView = DetailView;
