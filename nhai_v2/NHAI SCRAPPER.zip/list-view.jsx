/* global React, Icons, StatusTag, TypeTag, ConfTag, Spark, fmtINR, fmtINRPlain, daysUntil, fmtDate */
const { useState: useStateL, useMemo } = React;

// Filter chips state shape: {status, type, state, deadline}
function ListView({ tweaks, onOpen }) {
  const [density, setDensity] = useStateL(tweaks.density || "normal"); // compact / normal / roomy
  const [view, setView] = useStateL("table"); // table | cards
  const [query, setQuery] = useStateL("");
  const [filters, setFilters] = useStateL({ status: "active", type: null, state: null });
  const [sortBy, setSortBy] = useStateL("deadline");

  const tenders = window.TENDERS;

  const filtered = useMemo(() => {
    let r = tenders.filter(t => {
      if (filters.status && t.status !== filters.status) return false;
      if (filters.type && t.type !== filters.type) return false;
      if (filters.state && t.state !== filters.state) return false;
      if (query) {
        const q = query.toLowerCase();
        return (
          t.title.toLowerCase().includes(q) ||
          t.no.toLowerCase().includes(q) ||
          t.id.includes(q) ||
          t.nh.toLowerCase().includes(q) ||
          t.state.toLowerCase().includes(q)
        );
      }
      return true;
    });
    if (sortBy === "deadline") r.sort((a,b) => new Date(a.deadline) - new Date(b.deadline));
    if (sortBy === "value") r.sort((a,b) => b.estValue - a.estValue);
    if (sortBy === "match") r.sort((a,b) => b.match - a.match);
    return r;
  }, [tenders, filters, query, sortBy]);

  // Stats
  const active = tenders.filter(t => t.status === "active");
  const totalValue = active.reduce((s, t) => s + t.estValue, 0);
  const urgent = active.filter(t => daysUntil(t.deadline) <= 14).length;
  const analyzed = tenders.filter(t => t.analyzed).length;

  return (
    <div style={{ display: "flex", flexDirection: "column", flex: 1, minHeight: 0 }}>
      {/* Page head */}
      <div className="page-head">
        <div>
          <div className="crumb">Workspace · Tenders</div>
          <h1>Active tenders, week of 04 May 2026</h1>
        </div>
        <div className="right">
          <button className="btn"><span style={{display:"flex"}}>{Icons.download}</span> Export CSV</button>
          <button className="btn"><span style={{display:"flex"}}>{Icons.bell}</span> Saved alerts</button>
          <button className="btn primary"><span style={{display:"flex"}}>{Icons.layers}</span> Run analysis</button>
        </div>
      </div>

      {/* Stats */}
      <div className="stat-row">
        <div className="stat">
          <div className="label">Active tenders</div>
          <div className="value">{active.length}<span className="unit">on portal</span></div>
          <div className="meta"><span className="delta-up">▲ 3</span> this week · {analyzed} analyzed</div>
        </div>
        <div className="stat">
          <div className="label">Pipeline — est. value</div>
          <div className="value">{fmtINR(totalValue)}<span className="unit">across {active.length} RFPs</span></div>
          <Spark data={[12, 18, 15, 22, 19, 28, 25, 32, 30, 38, 42, 48]} color="var(--accent-2)" />
        </div>
        <div className="stat">
          <div className="label">Closing in ≤ 14 days</div>
          <div className="value">{urgent}<span className="unit">tenders</span></div>
          <div className="meta">
            <span style={{ color: "var(--danger)" }}>● 2 in 4 days</span>
            <span>·</span>
            <span>{urgent - 2} in 5–14 days</span>
          </div>
        </div>
        <div className="stat">
          <div className="label">EY eligibility match</div>
          <div className="value">76<span className="unit">% avg.</span></div>
          <div className="pipebar">
            <span style={{ width: "42%", background: "var(--ok)" }} />
            <span style={{ width: "32%", background: "var(--warn)" }} />
            <span style={{ width: "26%", background: "var(--danger)" }} />
          </div>
          <div className="meta" style={{ marginTop: 4 }}>
            <span>5 high · 4 medium · 3 low</span>
          </div>
        </div>
      </div>

      {/* Tools */}
      <div className="tools">
        <div className="searchbar" style={{ width: 380 }}>
          <span style={{ display: "flex", color: "var(--ink-4)" }}>{Icons.search}</span>
          <input value={query} onChange={(e) => setQuery(e.target.value)}
                 placeholder="Search tender no., title, NH-number, state, ID…" />
          {!query && <span className="kbd">⌘K</span>}
        </div>
        <span className="sep" />
        {[
          { k: "status", v: "active", label: "Active" },
          { k: "status", v: "closed", label: "Archive" },
        ].map(c => (
          <button key={c.label}
                  className={"chip" + (filters[c.k] === c.v ? " on" : "")}
                  onClick={() => setFilters(f => ({ ...f, [c.k]: f[c.k] === c.v ? null : c.v }))}>
            {c.label}
          </button>
        ))}
        <span className="sep" />
        {[
          { k: "type", v: "2-stage", label: "2-stage" },
          { k: "type", v: "single-stage", label: "Single-stage" },
        ].map(c => (
          <button key={c.label}
                  className={"chip" + (filters[c.k] === c.v ? " on" : "")}
                  onClick={() => setFilters(f => ({ ...f, [c.k]: f[c.k] === c.v ? null : c.v }))}>
            {c.label}
          </button>
        ))}
        <button className="chip">+ Add filter</button>
        <div style={{ flex: 1 }} />
        <select className="chip" value={sortBy} onChange={(e) => setSortBy(e.target.value)}
                style={{ background: "var(--paper)", paddingRight: 8 }}>
          <option value="deadline">Sort: Deadline</option>
          <option value="value">Sort: Est. value</option>
          <option value="match">Sort: Match score</option>
        </select>
        <span className="density-toggle">
          <button className={view === "table" ? "on" : ""} onClick={() => setView("table")} title="Table">
            {Icons.table}
          </button>
          <button className={view === "cards" ? "on" : ""} onClick={() => setView("cards")} title="Cards">
            {Icons.cards}
          </button>
        </span>
        {view === "table" && (
          <span className="density-toggle">
            <button className={density === "compact" ? "on" : ""} onClick={() => setDensity("compact")} title="Compact">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
            </button>
            <button className={density === "normal" ? "on" : ""} onClick={() => setDensity("normal")} title="Normal">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
            </button>
            <button className={density === "roomy" ? "on" : ""} onClick={() => setDensity("roomy")} title="Roomy">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M4 5h16M4 12h16M4 19h16"/></svg>
            </button>
          </span>
        )}
      </div>

      {/* List */}
      <div className="list-wrap">
        {view === "table" ? (
          <table className={"tlist " + density}>
            <colgroup>
              <col style={{ width: 90 }} />
              <col style={{ width: "auto" }} />
              <col style={{ width: 96 }} />
              <col style={{ width: 110 }} />
              <col style={{ width: 110 }} />
              <col style={{ width: 140 }} />
              <col style={{ width: 130 }} />
              <col style={{ width: 110 }} />
            </colgroup>
            <thead>
              <tr>
                <th>ID</th>
                <th>Tender</th>
                <th>Type</th>
                <th>NH · Length</th>
                <th>Est. value</th>
                <th>Deadline <span className="sort">▼</span></th>
                <th>EY match</th>
                <th>Confidence</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(t => {
                const d = daysUntil(t.deadline);
                const urgent = d <= 7;
                return (
                  <tr key={t.id} onClick={() => onOpen(t.id)}>
                    <td className="id">{t.id}</td>
                    <td className="title-cell">
                      {t.title}
                      <span className="sub">
                        <span className="mono" style={{color:"var(--ink-3)"}}>{t.no}</span> · {t.state}
                      </span>
                    </td>
                    <td><TypeTag t={t.type} /> </td>
                    <td className="num">
                      {t.nh}
                      <div style={{fontSize:11,color:"var(--ink-4)",marginTop:3}}>{t.length} km</div>
                    </td>
                    <td className="num">{fmtINR(t.estValue)}</td>
                    <td className={"deadline " + (urgent ? "urgent" : "")}>
                      {fmtDate(t.deadline)}
                      <span className="days">{d > 0 ? `in ${d} days` : `${-d}d ago`}</span>
                    </td>
                    <td>
                      <div className="match">
                        <div className="match-bar"><span style={{ width: `${t.match}%` }} /></div>
                        <span className="match-num">{t.match}</span>
                      </div>
                    </td>
                    <td><ConfTag c={t.confidence} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        ) : (
          <div className="cardgrid">
            {filtered.map(t => {
              const d = daysUntil(t.deadline);
              return (
                <div key={t.id} className="tcard" onClick={() => onOpen(t.id)}>
                  <div className="row1">
                    <div>
                      <div className="id">#{t.id} · <span className="mono">{t.no}</span></div>
                      <h3>{t.title}</h3>
                    </div>
                    <ConfTag c={t.confidence} />
                  </div>
                  <div className="meta">
                    <span><b>{t.nh}</b> · {t.state}</span>
                    <span><b>{t.length} km</b></span>
                    <span><b>{fmtINR(t.estValue)}</b></span>
                  </div>
                  <div style={{display:"flex",alignItems:"center",gap:8,marginTop:4}}>
                    <span className="match-bar" style={{maxWidth:90}}><span style={{width:`${t.match}%`}} /></span>
                    <span className="mono" style={{fontSize:11,color:"var(--ink-3)"}}>{t.match}% match</span>
                  </div>
                  <div className="footer">
                    <TypeTag t={t.type} />
                    <span className="mono" style={{fontSize:11.5,color: d <= 7 ? "var(--danger)" : "var(--ink-4)"}}>
                      {fmtDate(t.deadline)} · {d > 0 ? `${d}d left` : `${-d}d ago`}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="pager">
        <span>Showing {filtered.length} of {tenders.length} · synced 14 min ago from <span className="mono">nhai.gov.in/api/tenderlist</span></span>
        <div className="pager-actions">
          <button className="btn ghost" disabled>← Prev</button>
          <button className="btn ghost">Next →</button>
        </div>
      </div>
    </div>
  );
}
window.ListView = ListView;
